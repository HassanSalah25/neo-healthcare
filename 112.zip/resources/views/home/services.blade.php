@extends('layouts.master')
@section('content')
    <div class="page-header">
    <div class="container">

        <div class="page-header__image">
            <picture>
                <source srcset="{{asset('assets/images/page-header.webp?v=33')}}" type="image/webp">
                <img src="{{asset('assets/images/page-header.webp?v=33')}}" draggable="false" alt="page image" data-aos="zoom-out">
            </picture>
        </div>


        <h1 class="h3" data-aos="fade-up" data-aos-delay="100">خدمات عيادات نيو</h1>

    </div>
</div>


    <section class="services d-pad">
        <div class="container">

            <div class="section-title"><h2 class="title" data-aos="fade-up">
    <span class="color">
    تخصصات
    </span>
                    نيو
                </h2>
                <p data-aos="fade-up" data-aos-delay="100">
                    تصفح جميع خدمات عيادات نيو حسب التخصص.
                </p></div>


            <div class="services__container" data-aos="fade-up" data-aos-delay="300">
                @foreach(\App\Models\ServiceCategory::all() as $category)
                    <a href="{{route('website.service.view',$category->id)}}" class="service d-block">
                        <div class="service__image" data-aos="zoom-out">
                            <picture>
                                <source srcset="{{asset($category->getImg())}}" type="image/webp" />
                                <img src="{{asset($category->getImg())}}" draggable="false" loading="lazy" />
                            </picture>
                        </div>
                        <div class="service__title">
                            <h3 class="h5">
                              {{$category->name}}
                            </h3>
                        </div>
                    </a>
                @endforeach


            </div>
        </div>
    </section>


    @include('components.book-now')


    @include('components.doctors')


    @include('components.blogs')


{{--    @include('components.partners')--}}

@endsection
