@extends('layouts.master')
@section('content')


    <div class="page-header">
        <div class="container">

            <div class="page-header__image">
                <picture>
                    <source srcset="{{asset($blog->getImg())}}" type="image/webp" />
                    <img src="{{asset($blog->getImg())}}" draggable="false" alt="" data-aos="zoom-out" />
                </picture>
            </div>


            <h1 class="h3" data-aos="fade-up" data-aos-delay="100">
                {{$blog->title}}
            </h1>

        </div>
    </div>


    <section itemscope itemtype="http://schema.org/Article" class="article d-pad">
        <div class="container">
            <div class="row">

                <div class="col-lg-7">

                    <div class="article-title" data-aos="fade-up">
                        <h2 itemprop="name" itemprop="articleBody" class="title"> {{$blog->title}}</h2>
                        <span itemprop="datePublished" class="date small"> {{$blog->created_at}}</span>
                    </div>


                    <div class="article__content">

                        <div class="article__image" data-aos="zoom-out">
                            <picture>
                                <source srcset="{{asset($blog->getImg())}}" type="image/webp" />
                                <img src="{{asset($blog->getImg())}}" draggable="false" alt="" data-aos="zoom-out" />
                            </picture>
                        </div>

                        <div itemprop="articleBody">
                            {{$blog->content}}
                        </div>
                    </div>


                    <div class="article__block article__add-comment" data-aos="fade-up" >
                        <h2 class="h4 article__section-title">أضف تعليقك</h2>
                        <form action="" class="article__form" >
@csrf
                            <div class="form-row" >
                                <div class="form-group col-md-6">
                                    <label for="commentName" class="sr-only" >الاسم بالكامل</label>
                                    <input type="text" class="form-control" style="background-color: #d5d5d5" id="commentName" name="commenter" placeholder="الاسم بالكامل" required>
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="commentEmail" class="sr-only">البريد الإلكتروني</label>
                                    <input type="email" class="form-control" style="background-color: #d5d5d5" id="commentEmail" name="email" placeholder="البريد الإلكتروني" required>
                                </div>
                                <div class="form-group col-md-12">
                                    <label for="commentMessage" class="sr-only">أضف تعليقك</label>
                                    <textarea class="form-control" style="background-color: #d5d5d5" id="commentMessage" name="content" placeholder="أضف تعليقك.." required></textarea>
                                </div>
                                <div class="col-md-12">
                                    <button type="submit"  class="btn btn-brand-primary">أضف تعليقك</button>
                                </div>
                            </div>
                        </form>
                    </div>



                </div>


                <div class="col-lg-5">
                    <div class="article__side">

                        <div class="article__side-block book-now">
                            <div class="container">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <h2 class="h4" data-aos="fade-up">
                                            هل ترغب في حجز موعدك الآن؟
                                        </h2>
                                    </div>
                                    <div class="col-lg-12">
                                        <a href="{{route('website.appointment')}}" class="btn btn-brand-white Booking_ads" data-aos="fade-up" data-aos-delay="100">
                                            إحجز الآن
                                            <svg class="btn-icon">
                                                <use href="{{asset('assets/images/icons/icons.svg?v=33#book')}}"></use>
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>


                        <div class="article__side-block">

                            <div class="overlay-bg opening" data-aos="zoom-out-up">
                                <div class="overlay-bg__icon">
                                    <svg class="icon">
                                        <use href="{{asset('assets/images/icons/icons.svg?v=32#derma')}}"></use>
                                    </svg>
                                </div>
                                <div class="row overlay-bg__block justify-content-center">
                                    <h2 class="h6 color"> السبت إلى الخميس:
                                    </h2>
                                    <h7 style="color: white"> 9:00 صباحًا إلى 8:00 مساءً</h7>
                                </div>

                            </div>

                        </div>



{{--                        <div class="article__side-block article__subscribe" data-aos="fade-up">--}}
{{--                            <div class="footer__form">--}}
{{--                                <h6>إشترك لتصلك أحدث عروض وخدمات نيو الطبية:</h6>--}}
{{--                                <form method="POST" action="https://ramclinics.net/post/subscribe">--}}
{{--                                    <input type="hidden" name="_token" value="Qjgc5P4mpdMZ30u6tJNx3cQafs7YBXjIntY4gv47"> <div class="form-group">--}}
{{--                                        <label for="subscribeNewsletter" class="sr-only">أدخل رقم الجوال</label>--}}
{{--                                        <span class="form-icon">--}}
{{--<svg class="icon">--}}
{{--<use href="/web/assets/images/icons/icons.svg?v=33#iphone"></use>--}}
{{--</svg>--}}
{{--</span>--}}
{{--                                        <input type="tel" name="phone" class="form-control" onchange="validateContact(this)" maxlength="10" placeholder="أدخل رقم الجوال" id="subscribeNewsletter" required>--}}
{{--                                        <button class="btn btn-brand-primary">إشترك</button>--}}
{{--                                        <div class="invalid-feedback">--}}
{{--                                            يجب أن يكون هذا الحقل جوالًا سعوديًا (05xxxxxxxx).--}}
{{--                                        </div>--}}
{{--                                    </div>--}}
{{--                                </form>--}}
{{--                            </div>--}}
{{--                        </div>--}}


                        <div class="article__side-block article__related">
                            <div class="footer__form" data-aos="fade-up">
                                <h3 class="h5">مقالات ذات صلة</h3>
                                @foreach($blogs as $blog)

                                    <div class="blog__article" data-aos="fade-up" data-aos-delay="100">
                                        <a href="{{route('website.blog.show',$blog->id)}}" class="d-block blog__article-photo">
                                            <picture>
                                                <source srcset="{{asset($blog->getImg())}}" type="image/webp" />
                                                <img src="{{asset($blog->getImg())}}" draggable="false" loading="lazy" alt="alt" />
                                            </picture>
                                        </a>
                                        <div class="blog__article-info">
                                            <p>
                                                {{$blog->content}}
                                                <span class="date small">{{$blog->created_at}}</span>
                                            </p>
                                        </div>
                                    </div>
                                @endforeach

                            </div>
                        </div>

                    </div>
                </div>

            </div>
        </div>
    </section>


{{--@include('components.partners')--}}




@endsection
