@extends('layouts.master')
@section('content')
    <div class="page-header">
        <div class="container">

            <div class="page-header__image">
                <picture>
                    <source srcset="{{asset('assets/images/page-header.webp?v=33')}}" type="image/webp">
                    <img src="{{asset('assets/images/page-header.webp?v=33')}}" draggable="false" alt="page image" data-aos="zoom-out">
                </picture>
            </div>


            <h1 class="h3" data-aos="fade-up" data-aos-delay="100">
                إحجز موعدك الآن
            </h1>

        </div>
    </div>


    <div class="about d-pad">
        <div class="container">
            <div class="about__container d-flex align-items-center">

                <div class="about__image">
                    <picture>
                        <source srcset="{{asset('assets/images/about.webp')}}" type="image/webp"><img src="{{asset('assets/images/about.webp')}}" draggable="false" alt="alt" data-aos="zoom-out">
                    </picture>
                </div>


                <div class="about__text">
                    <div class="overline" data-aos="fade-up">
                        عن عيادات نيو
                    </div>
                    <h2 class="title" data-aos="fade-up" data-aos-delay="100">
                        الجودة،، السلامة،، رضا العملاء،، <span class="color">وأخيراً المصداقية</span>
                    </h2>
                    <p class="lead" data-aos="fade-up">
                        عن المركز

                        مركز نيو الطبي هي شبكة متكاملة من مراكز الرعاية الصحية التي تضم العيادات الطبية المتخصصة والمختبرات الطبية ومراكز الاشعة .
                        كل ذلك تحت مظلة واحدة لتوفير رعاية صحية مهنية كاملة وشاملة تحت سقف واحد. أيضًا يوفر مركز نيو الطبي  أفضل رعاية على المستوى المحلي و الدولي . يتمتع مركز نيو الطبي بخبرة خاصة في مجال الرعاية الصحية  نحن نقدم خدمات رعاية صحية مبتكرة للأفراد وكذلك المجموعات والشركات ، ونقدم التوجيه والدعم والرعاية المستمرة كما لدينا خدمة تشخيص المريض بالمركز اذا كان بحاجة اجراء دخول لاجراء تدخل جراحي حسب المطلوب و نود ابلاغكم بأن لدينا تعاقدات مع مستشفى الخالدي و مستشفى الاستشاري و مستشفى فرح الطبي و مستشفى عبد الهادي بحالة تم اجراء عمليات

                        رؤيتنا
                        الريادة في الرعاية الصحية لنكون من  الرائديين في مجال الرعاية الصحية  في المملكة الأردنية الهاشمية.

                        مهمتنا
                        تقديم  أفضل رعاية صحية  تشخيصيية ممكنة بأفضل الخبرات و بأنسب الاسعار من خلال كادر مؤهل و معتمد من الممرضيين و الاطباء و اداريين .

                        قيمنا
                        المهنية , الإلتزام , النزاهة , التعاطف
                    </p>
                </div>

            </div>
        </div>
    </div>


    @include('components.statiscts')


    <div class="about__blocks">
        <div class="container">
            <div class="about__container d-flex">

                <div class="about__block">
                    <div class="about__block-icons" data-aos="zoom-in">
                        <svg class="icon" >
                            <use href="{{asset('assets2/images/icons/icons.svg#vision')}}"></use>
                        </svg>
                    </div>
                    <div class="about__block-text">
                        <h2 class="h6" data-aos="fade-up" data-aos-delay="100">الرؤية</h2>
                        <p data-aos="fade-up" data-aos-delay="200">
                            الريادة فى تقديم خدمات الرعاية الطبية والتي تتوافق مع أعلى المعايير المحلية والدولية.
                        </p>
                    </div>
                </div>


                <div class="about__block">
                    <div class="about__block-icons" data-aos="zoom-in">
                        <svg class="icon">
                            <use href="{{asset('assets2/images/icons/icons.svg#message')}}"></use>
                        </svg>
                    </div>
                    <div class="about__block-text">
                        <h2 class="h6" data-aos="fade-up" data-aos-delay="100">الرسالة</h2>
                        <p data-aos="fade-up" data-aos-delay="200">
                            تقديم الخدمات الطبية بجودة عالية من خلال الكوادر المؤهلة والتكنولوجيا المتقدمة وشبكة الفروع الواسعة.
                        </p>
                    </div>
                </div>


                <div class="about__block">
                    <div class="about__block-icons" data-aos="zoom-in">
                        <svg class="icon">
                            <use href="{{asset('assets2/images/icons/icons.svg#values')}}"></use>
                        </svg>
                    </div>
                    <div class="about__block-text">
                        <h2 class="h6" data-aos="fade-up" data-aos-delay="100">القيم</h2>
                        <p data-aos="fade-up" data-aos-delay="200">
                            الجودة، السلامة، العمل الجماعي، رضا العملاء، رضا الموظفين، والمصداقية.
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>


    <section class="book-now">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center">
                    <h2 class="h3" data-aos="fade-up">
                        هل ترغب في حجز موعدك الآن؟
                    </h2>
                </div>
                <div class="col-lg-6 d-flex align-items-center justify-content-lg-end">
                    <a href="{{route('website.appointment')}}" class="btn btn-brand-white Booking_ads" data-aos="zoom-in">
                        إحجز الآن
                        <svg class="btn-icon">
                            <use href="{{asset('assets/images/icons/icons.svg#book')}}"></use>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>


    <section>
        <div class="container">

            <div class="title-container" data-aos="fade-up">
                <h2 class="title">
                    فريقنا <span class="color">الرائع</span>
                </h2>
                <a href="{{route('website.doctor')}}" class="btn btn-brand-link">
                    عرض جميع أطباء
                    <svg class="btn-icon">
                        <use href="{{asset('assets/images/icons/icons.svg#btn-arrow')}}"></use>
                    </svg>
                </a>
            </div>

            <div class="title-container" data-aos="fade-up">
                <p>
                    نخبة من الإستشاريين والإخصائيين في كافة التخصصات الطبية (أسنان – جلدية – طبية) سيقومون بخدمتكم. أغلب أعضاء فريقنا لديهم الماجستير
                    أو الدكتوراه من أعلى الجامعات الرائدةوالخبرة المميزة في كافة التخصصات الطبية.
                </p>
                <p>
                    تضم مجموعة عيادات رام أكثر من 400 طبيب وطبيبة من خلال شبكة واسعة من الفروع التي تضم 20 فرع داخل المملكة العربية السعودية والبحرين
                    والامارات ومصر. كل هذا الفريق يعمل من أجل أن يقدم لك أفضل علاج.
                </p>
            </div>


            @include('components.doctors')

        </div>
    </section>

{{--
    <div class="about__more">
        <div class="container">
            <h2 class="title" data-aos-delay="fade-up">
                أنت في <span class="color">أيد آمنة</span>
            </h2>
            <div class="about__container d-flex">

                <div class="about__more-block d-flex">
                    <div class="about__more-block-image">
                        <picture>
                            <source srcset="/web/assets/images/about-more-1.webp" type="image/webp"><img src="/web/assets/images/about-more-1.jpg" draggable="false" loading="lazy" alt="alt" data-aos="zoom-out">
                        </picture>
                    </div>
                    <div class="about__more-block-text" data-aos="fade-up">
                        <p>
                            منذ 2007 تتخصص مجموعة رام في تقديم خدمات الرعاية الطبية بأحدث التقنيات العالمية في كافة التخصصات، حيث نعمل على إرضاء كافة
                            المرضى من خلال تقديم خدمات عالية الجودة على أيدي أمهر الكوادر الطبية بتكلفة مناسبة.
                        </p>
                    </div>
                </div>


                <div class="about__more-block d-flex">
                    <div class="about__more-block-image">
                        <picture>
                            <source srcset="/web/assets/images/about-more-2.webp" type="image/webp"><img src="/web/assets/images/about-more-2.jpg" draggable="false" loading="lazy" alt="alt" data-aos="zoom-out">
                        </picture>
                    </div>
                    <div class="about__more-block-text" data-aos="fade-up">
                        <p>
                            من خلال شبكة فروعنا الممتدة عبر المملكة العربية السعودية والبحرين لتصلوا الينا بسهولة و نعمل على توسيع شبكتنا لتغطي جميع
                            مناطق المملكة العربية السعودية والخليج العربي.
                        </p>
                    </div>
                </div>

            </div>
        </div>
    </div>--}}


{{--    @include('components.partners')--}}
@endsection
