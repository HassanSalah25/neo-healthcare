@extends('layouts.master')
@section('content')
<div class="page-header">
        <div class="container">

            <div class="page-header__image">
                <picture>
                    <source srcset="{{asset('assets/images/page-header.webp?v=33')}}" type="image/webp">
                    <img src="{{asset('assets/images/page-header.webp?v=33')}}" draggable="false" alt="page image" data-aos="zoom-out">
                </picture>
            </div>


            <h1 class="h3" data-aos="fade-up" data-aos-delay="100">
                إحجز موعدك الآن
            </h1>

        </div>
    </div>

<section class="book d-pad">
    <div class="container">

        <div class="section-title">
            <h2 class="title" data-aos="fade-up">
                إحجز موعدك <span class="color">الآن</span>
            </h2>
            <p data-aos="fade-up" data-aos-delay="100">
                يمكنك الحجز في شبكتة عيادات مراكز نيو الطبي للرعاية الصحية التي تضم عيادات طبية متخصصة.
            </p>
        </div>

        <div class="book__container">

            <div class="book__form">
                <form class="form" method="post" action="{{route('website.appointment.store')}}" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label class="col-lg-3 col-form-label">القسم</label>
                        <div class="col-lg-9">
                            <nav class="services-nav">
                                @foreach(\App\Models\ServiceCategory::all() as $category)
                                    <span onclick="updateServiceId({{$category->id}},this)" id="services-1" class="btn btn-service btn-brand-primary-5 {{$category->id == 2 ? 'active' : '' }} ">
                                    <svg class="icon">
                                    <use href="{{asset('assets/images/icons/icons.svg?v=33#medical')}}"></use>
                                    </svg>
                                    {{$category->name_ar}}
                                    </span>
                                @endforeach

                            </nav>

                        </div>
                    </div>

                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookService" class="col-lg-3 col-form-label">الخدمة</label>
                        <div class="col-lg-9">
                            <select class="custom-select" id="bookService" name="service" required>
                                <option >إختر الخدمة المناسبة لك</option>
                                @foreach(\App\Models\Service::where('service_category_id',2)->get() as $service)
                                <option value="{{$service->id}}" {{ isset($doctor) ? $service->id == $doctor->service->id ? "selected":"":""}}>{{$service->name_ar}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>


                    <div class="form-group row d-flex align-items-center" id="show_doctors" data-aos="fade-up">
                        <label for="bookDoctor" class="col-lg-3 col-form-label">الطبيب</label>
                        <div class="col-lg-9">
                            @if(isset($doctor))
                                <p id="doctor_input">{{$doctor->first_name_ar}}</p>
                                <input type="hidden" name="doctor_id" id="doctor_id" value="{{$doctor->id}}">
                            @else
                                <p id="doctor_input"></p>
                                <input type="hidden" name="doctor_id" id="doctor_id">
                            @endif
                        </div>
                    </div>

                    <h3 class="h5" data-aos="fade-up">البيانات الشخصية</h3>

                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookName" class="col-lg-3 col-form-label">الاسم بالكامل</label>
                        <div class="col-lg-9">
                            <input type="text" class="form-control" id="bookName" placeholder="أدخل الإسم بالكامل" name="name" value required>
                        </div>
                    </div>


                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookPhone" class="col-lg-3 col-form-label">الجوال</label>
                        <div class="col-lg-9">
                            <input type="tel" class="form-control" onchange="validateContact(this)" maxlength="10" id="bookPhone" placeholder="أدخل رقم الجوال (05xxxxxxxx)." name="phone" value required>
                            <div class="invalid-feedback">
                                يجب أن يكون هذا الحقل جوالًا سعوديًا (05xxxxxxxx).
                            </div>
                        </div>
                    </div>


                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookEmail" class="col-lg-3 col-form-label">البريد الإلكتروني</label>
                        <div class="col-lg-9">
                            <input type="email" class="form-control" id="bookEmail" placeholder="أدخل البريد الإلكتروني" name="email" value required>
                        </div>
                    </div>


                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookDate" class="col-lg-3 col-form-label">التاريخ المناسب</label>
                        <div class="col-lg-9">
                            <input onchange="return checkAvailableAppointment();" type="date" class="form-control" name="attendance_date" value id="bookDate" required>
                        </div>
                    </div>




                    <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                        <label for="bookTime1" class="col-lg-3 col-form-label">التوقيت</label>
                        <div class="col-lg-9">
                            <select class="custom-select" id="bookTime1" name="available_time" required>
                                <option value>إختر التوقيت المناسب لك</option>
                                <option value="1">صباحي</option>
                                <option value="2">مسائي</option>
                            </select>
                        </div>
                    </div>



                    <div class="row d-flex align-items-center">
                        <div class="col-lg-3"></div>
                        <div class="col-lg-9">
                            <button type="submit" class="btn btn-brand-primary btn-form Booking_ads" data-aos="fade-up">
                                إحجز موعدك الآن
                                <svg class="btn-icon">
                                    <use href="/web/assets/images/icons/icons.svg?v=33#book"></use>
                                </svg>
                            </button>
                        </div>
                    </div>

                </form>
            </div>


            <div class="book__image">
                <picture>
                    <source srcset="{{asset('assets/images/book.webp?v=33')}}" type="image/webp">
                    <img src="{{asset('/uploads/services/2022/02/14/20220214012828842243950_services.jpg?v=33')}}" draggable="false" alt="book now" data-aos="zoom-out">
                </picture>
            </div>

        </div>
    </div>
</section>

{{--@include('components.partners')--}}
@endsection


@push('scripts')
    <script>
        function updateServiceId(id,th)
        {
            console.log('Updating service');


            data = {
                'id': id
            }
            $.ajax({
                url: '{{route('website.service.service.show')}}',
                method: 'GET',
                data: data,
                success: function (response) {
                    $('#bookService').empty();
                    $('.btn-service').removeClass('active');
                    $(th).addClass('active');
                    var selectElement = $('#bookService');
                    var option = $('<option></option>');
                    option.text('إختر الخدمة المناسبة لك');   // Set the text of the option
                    selectElement.append(option);  // Append the option to the <select> element
                    $.each(response, function(index, item) {
                        var option = $('<option></option>');
                        option.val(item['id']);   // Set the value of the option
                        option.text(item['name_ar']);   // Set the text of the option
                        selectElement.append(option);  // Append the option to the <select> element
                    });
                },
                error: function (xhr, status, error) {
                    console.error('Error: ' + error);
                }
            });
        }
    </script>
@endpush
