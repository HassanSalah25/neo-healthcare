@extends('layouts.master')
@section('content')

    <div class="page-header">
        <div class="container">

            <div class="page-header__image">
                <picture>
                    <source srcset="{{asset('assets/images/page-header.webp?v=33')}}" type="image/webp">
                    <img src="{{asset('assets/images/page-header.webp?v=33')}}" draggable="false" alt="page image" data-aos="zoom-out">
                </picture>
            </div>


            <h1 class="h3" data-aos="fade-up" data-aos-delay="100">
                إحجز موعدك الآن
            </h1>

        </div>
    </div>

    <section itemscope itemtype="http://schema.org/Physician" class="doctors-profile d-pad">
        <div class="container">
            <div class="row">

                <div class="col-lg-4">
                    <div class="filters">

                        <div class="doctor__image" style="height: 40rem;">
                            <picture>
                                <source srcset="{{asset($doctor->getImg())}}" type="image/webp">
                                <img itemprop="image" src="{{asset($doctor->getImg())}}" draggable="false" data-aos="zoom-out" alt>
                            </picture>
                        </div>




                    </div>
                </div>


                <div class="col-lg-8">

                    <div class="profile__container">
                        <div class="title-container align-items-start" data-aos="fade-up">
                            <a itemprop="url" href="" class="h4 title">
                                <h2 class="h4 title" itemprop="name">
                                    {{ $doctor->first_name_ar }}
                                </h2>
                                    </a>
                            <a href="{{route('website.appointment.doctor',$doctor->id)}}" class="btn btn-brand-primary Booking_ads" itemprop="tourBookingPage">
                                إحجز الآن مع {{ $doctor->first_name_ar }}
                            </a>
                        </div>
                    </div>


                    <div class="profile__container" id="profileAbout">
                        <h3 class="h5 title" data-aos="fade-up">
                            عن الطبيب
                        </h3>
                        <div class="section-bg" data-aos="fade-up" data-aos-delay="100">
                            <h4 class="h6">{{ $doctor->first_name_ar }}</h4>
                            <p>
                                {{ $doctor->specialty_ar }}
                            </p>
                            <div class="row">
                                <div class="col-md-4">
                                    <h4 class="h6">سنوات الخبرة:</h4>
                                    <span class="h3 color" itemprop="foundingDate">{{ $doctor->years_of_experience }}</span>
                                    <small class="d-block">سنوات</small>
                                </div>
                            </div>
                        </div>
                    </div>



                    <div class="profile__container" id="profileServices">
                        <h3 class="h5 title">
                            الخدمات التي يقدمها الطبيب
                        </h3>
                        <div class="profile__services d-flex">

                            <div class="profile__service">

                                <div class="service__image">
                                    <picture>
                                        <source srcset="{{asset($doctor->service->getImg())}}" type="image/webp"><img src="{{asset($doctor->service->getImg())}}" draggable="false" loading="lazy" alt="service" data-aos="zoom-out">
                                    </picture>
                                </div>


                                <div class="service__title d-block text-center">
                                    <h4 class="h6" data-aos="fade-up">
                                        {{$doctor->service->name_ar}}
                                    </h4>
                                </div>


                                <div class="profile__service-btn" data-aos="fade-up" data-aos-delay="100">
                                    <a href="{{route('website.appointment.doctor',$doctor->id)}}" class="btn btn-brand-white Booking_ads">
                                        إحجز الآن
                                        <svg class="btn-icon">
                                            <use href="{{asset("assets/images/icons/icons.svg?v=33#book")}}"></use>
                                        </svg>
                                    </a>
                                </div>

                            </div>

                        </div>
                    </div>

                    <div class="profile__container" id="profileServices">
                        <h3 class="h5 title">
                            الشهادات
                        </h3>
                    </div>
                    <div class="profile__service">
                        <div class="service__image">
                            <picture>
                                <source srcset="{{asset($doctor->service->getImg()??null)}}" type="image/webp"><img src="{{asset($doctor->service->getImg()??null)}}" draggable="false" loading="lazy" alt="service" data-aos="zoom-out">
                            </picture>
                        </div>
                    </div>




                </div>

            </div>
        </div>
    </section>


    <section class="book-now">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 d-flex align-items-center">
                    <h2 class="h3" data-aos="fade-up">
                        هل ترغب في حجز موعدك الآن؟
                    </h2>
                </div>
                <div class="col-lg-6 d-flex align-items-center justify-content-lg-end">
                    <a href="{{route('website.appointment.doctor',$doctor->id)}}" class="btn btn-brand-white Booking_ads" data-aos="zoom-in">
                        إحجز موعدك الآن
                        <svg class="btn-icon">
                            <use href="{{asset('assets/images/icons/icons.svg?v=33#book')}}"></use>
                        </svg>
                    </a>
                </div>
            </div>
        </div>
    </section>


@endsection
