
<section class="services d-pad">
    <div class="container">

        <div class="section-title">
            <h2 class="title" data-aos="fade-up">
                <span class="color">خدمات </span> عيادات نيو
            </h2>
            <p data-aos="fade-up" data-aos-delay="100">
                ستعيش تجربة فريدة أثناء علاجك لأننا رواد في الرعاية الصحية مع بيئة مريحة و
                الرعاية المتكاملة التي نقدمها لك.
            </p>
        </div>


        <div class="services__container" data-aos="fade-up" data-aos-delay="300">
@foreach(\App\Models\ServiceCategory::where('name','General')->first()->services as $category)
                <a href="https://ramclinics.net/dental" class="service d-block">
                    <div class="service__image" data-aos="zoom-out">
                        <picture>
                            <source class="lazyload" src="{{asset($category->getImg())}}" data-srcset="{{asset($category->getImg())}}" type="image/webp" />
                            <img class="lazyload" src="{{asset($category->getImg())}}" data-src="{{asset($category->getImg())}}" draggable="false" loading="lazy" alt />
                        </picture>
                    </div>
                    <div class="service__title">
                        <h3 class="h5">
                            <span class="color"> {{$category->name}} </span>

                        </h3>
                    </div>
                </a>
@endforeach




        </div>
    </div>
</section>
