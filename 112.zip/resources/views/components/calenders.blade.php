
<div class="slider-overlay">
    <div class="container">
        <div class="slider-overlay__container w-100 h-100">

            <div class="overlay-bg__times w-100 h-100">

                <div class="overlay-bg " data-aos="zoom-out-up">

                </div>


                <div class="overlay-bg opening w-100 h-100" data-aos="zoom-out-up">
                    <div class="overlay-bg__icon" >
                        <svg class="icon">
                            <use href="{{asset('assets/images/icons/icons.svg?v=32#clock')}}"></use>
                        </svg>
                    </div>
                    <div class="row overlay-bg__block justify-content-center">
                        <h2 class="h6 color"> السبت إلى الخميس:
                            </h2>
                            <h7 style="color: white"> 9:00 صباحًا إلى 8:00 مساءً</h7>
                    </div>

                </div>


                <div class="overlay-bg " data-aos="zoom-out-up">

                </div>

            </div>
        </div>
    </div>
</div>
