@extends('layouts.master')
@section('content')
    <div class="page-header">
        <div class="container">

            <div class="page-header__image">
                <picture>
                    <source srcset="{{asset('assets/images/page-header.webp?v=33')}}" type="image/webp">
                    <img src="{{asset('assets/images/page-header.webp?v=33')}}" draggable="false" alt="page image" data-aos="zoom-out">
                </picture>
            </div>


            <h1 class="h3" data-aos="fade-up" data-aos-delay="100">
                قيم مستوى الخدمات
            </h1>

        </div>
    </div>

    <section class="rate d-pad">
        <div class="container">

            <div class="section-title">
                <h2 class="title aos-init aos-animate" data-aos="fade-up">
                    سعداء بتقديم خدماتنا إليكم<br>
                    <span class="color">قيم مستوى الخدمات الآن</span>
                </h2>
                <p data-aos="fade-up" data-aos-delay="100" class="aos-init aos-animate">
                    قيم مستوى الخدمة التي قدمت إليك لتساعدنا على تحسين تجربتك إلى الأفضل
                </p>
            </div>

            <form class="form" method="post" action="{{route('website.feedback.store')}}" novalidate="novalidate">
                @csrf
                <div class="rate__container">



                    <div class="rate__form">
                        <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                            <label class="col-lg-3 col-form-label">القسم</label>
                            <div class="col-lg-9">
                                <nav class="services-nav">
                                <span onclick="updateServiceId(1)" id="services-1" class="btn btn-brand-primary-5 active ">
                                <svg class="icon">
                                <use href="{{asset('assets/images/icons/icons.svg?v=33#dental')}}"></use>
                                </svg>
                                Clinics
                                </span>
                                </nav>
                            </div>
                        </div>

                        <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                            <label for="bookService" class="col-lg-3 col-form-label">الخدمة</label>
                            <div class="col-lg-9">
                                <select class="custom-select" id="bookService" name="service" required>
                                    <option value>إختر الخدمة المناسبة لك</option>
                                    @foreach(\App\Models\Service::where('service_category_id',2)->get() as $service)
                                        <option value="{{$service->id}}" {{ isset($doctor) ? $service->id == $doctor->service->id ? "selected":"":""}}>{{$service->name_ar}}</option>
                                    @endforeach
                                </select>
                            </div>
                        </div>


                        <div class="form-group row d-flex align-items-center" data-aos="fade-up">
                            <label for="bookDoctor" class="col-lg-3 col-form-label">الطبيب</label>
                            <div class="col-lg-9">
                                @if(isset($doctor))
                                    <p id="doctor_input">{{$doctor->first_name_ar}}</p>
                                    <input type="hidden" name="doctor_id" id="doctor_id" value="{{$doctor->id}}">
                                @else
                                    <p id="doctor_input"></p>
                                    <input type="hidden" name="doctor_id" id="doctor_id">
                                @endif
                            </div>
                        </div>


                        <h3 class="h5 aos-init" data-aos="fade-up">البيانات الشخصية</h3>

                        <div class="form-group row d-flex align-items-center aos-init" data-aos="fade-up">
                            <label for="freeProgramName" class="col-lg-3 col-form-label">الاسم بالكامل</label>
                            <div class="col-lg-9">
                                <input type="text" class="form-control" id="freeProgramName" placeholder="أدخل الإسم بالكامل" name="name" value="" required="">
                                <div data-lastpass-icon-root="true" style="position: relative !important; height: 0px !important; width: 0px !important; float: left !important;"></div></div>
                        </div>


                        <div class="form-group row d-flex align-items-center aos-init" data-aos="fade-up">
                            <label for="freeProgramPhone" class="col-lg-3 col-form-label">الجوال</label>
                            <div class="col-lg-9">
                                <input type="tel" class="form-control" onchange="validateContact(this)" maxlength="10" id="freeProgramPhone" placeholder="أدخل رقم الجوال (05xxxxxxxx)." name="phone" value="" required="">
                                <div class="invalid-feedback">
                                    يجب أن يكون هذا الحقل جوالًا سعوديًا (05xxxxxxxx).
                                </div>
                            </div>
                        </div>


                        <div class="form-group row d-flex align-items-center aos-init" data-aos="fade-up">
                            <label for="freeProgramEmail" class="col-lg-3 col-form-label">البريد الإلكتروني</label>
                            <div class="col-lg-9">
                                <input type="email" class="form-control" id="freeProgramEmail" placeholder="أدخل البريد الإلكتروني" name="email" value="" required="">
                            </div>
                        </div>


                        <div class="row d-flex align-items-center">
                            <div class="col-lg-3"></div>
                            <div class="col-lg-9">
                                <button type="submit" class="btn btn-brand-primary btn-form aos-init" data-aos="fade-up">
                                    قيم مستوى الخدمات
                                </button>
                            </div>
                        </div>

                    </div>


                    <div class="rate__values">
                        <h3 class="h5 aos-init aos-animate" data-aos="fade-up">التقييم</h3>

                        <div class="rate__value aos-init aos-animate" data-aos="fade-up">
                            <h4 class="h6">مدى سهولة حجز المواعيد ؟</h4>
                            <input type="hidden" name="name_rate1" value="How easy is it to book appointments?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate1CompletelySatisfied" name="rate1" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate1CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate1Satisfied" name="rate1" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate1Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate1NotSatisfied" name="rate1" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate1NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى رضاكم عن الوقت المستغرق خلال رحلتكم العلاجية داخل العيادات؟</h4>
                            <input type="hidden" name="name_rate2" value="How satisfied are you with the time spent during your treatment journey inside the clinics?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate2CompletelySatisfied" name="rate2" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate2CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate2Satisfied" name="rate2" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate2Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate2NotSatisfied" name="rate2" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate2NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى رضاكم عن سعر الخدمة؟</h4>
                            <input type="hidden" name="name_rate3" value="How satisfied are you with the price of the service?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate3CompletelySatisfied" name="rate3" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate3CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate3Satisfied" name="rate3" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate3Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate3NotSatisfied" name="rate3" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate3NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى رضاكم عن الخدمة الطبية المقدمة؟</h4>
                            <input type="hidden" name="name_rate4" value="How satisfied are you with the provided medical service?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate4CompletelySatisfied" name="rate4" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate4CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate4Satisfied" name="rate4" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate4Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate4NotSatisfied" name="rate4" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate4NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">هل قام الطبيب بشرح الحالة الطبية والحلول المتاحة والتكلفة بالتفصيل؟</h4>
                            <input type="hidden" name="name_rate5" value="Did the doctor explain the medical condition, available solutions, and cost in detail?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate5CompletelySatisfied" name="rate5" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate5CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate5Satisfied" name="rate5" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate5Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate5NotSatisfied" name="rate5" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate5NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى رضاكم عن جودة خدمة الإستقبال؟</h4>
                            <input type="hidden" name="name_rate6" value="How satisfied are you with the quality of the reception service?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate6CompletelySatisfied" name="rate6" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate6CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate6Satisfied" name="rate6" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate6Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate6NotSatisfied" name="rate6" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate6NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى رضاكم عن التعقيم والنظافة العامة بالعيادات و مرافقها ؟</h4>
                            <input type="hidden" name="name_rate7" value="How satisfied are you with sterilization and general hygiene in clinics and their facilities?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate7CompletelySatisfied" name="rate7" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate7CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate7Satisfied" name="rate7" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate7Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate7NotSatisfied" name="rate7" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate7NotSatisfied">غير راضي</label>
                            </div>
                        </div>


                        <div class="rate__value aos-init" data-aos="fade-up">
                            <h4 class="h6">مدى احتمالية بأن توصي الأخرين بزيارة عيادات رام؟</h4>
                            <input type="hidden" name="name_rate8" value="How likely are you to recommend others to visit Ram Clinics?">
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate8CompletelySatisfied" name="rate8" value="CompletelySatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate8CompletelySatisfied">راضي جداً</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate8Satisfied" name="rate8" value="Satisfied" class="custom-control-input" checked="">
                                <label class="custom-control-label" for="rate8Satisfied">راضي</label>
                            </div>
                            <div class="custom-control custom-radio custom-control-inline">
                                <input type="radio" id="rate9NotSatisfied" name="rate8" value="NotSatisfied" class="custom-control-input">
                                <label class="custom-control-label" for="rate9NotSatisfied">غير راضي</label>
                            </div>
                        </div>

                    </div>

                </div>
            </form>
        </div>
    </section>


{{--    @include('components.partners')--}}
@endsection

