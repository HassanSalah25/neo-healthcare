
<section class="blog d-pad">
    <div class="container">

        <div class="title-container" data-aos="fade-up">
            <h2 class="title">
                أحدث <span class="color">المقالات</span>
            </h2>
            <a href="{{route('website.blog.index')}}" class="btn btn-brand-link">
                عرض جميع المقالات
                <svg class="btn-icon">
                    <use href="{{asset('assets/images/icons/icons.svg?v=32#btn-arrow')}}"></use>
                </svg>
            </a>
        </div>

        <div class="row">

            @foreach(\App\Models\Blog::limit(6)->get() as $blog) @endforeach
            <div class="col-lg-6">
                <div class="blog__article" data-aos="fade-up" data-aos-delay="100">
                    <a href="{{route('website.blog.show',$blog->id)}}" class="d-block blog__article-photo">
                        <picture>
                            <source srcset="{{asset($blog->getImg())}}" type="image/webp" />
                            <img src="{{asset($blog->getImg())}}" draggable="false" loading="lazy"/>
                        </picture>
                    </a>
                    <div class="blog__article-info">
                        <a href="{{route('website.blog.show',$blog->id)}}" class="overline">
                            مقالات عامة
                        </a>
                        <a href="{{route('website.blog.show',$blog->id)}}">
                            <h3 class="h5">{{$blog->title}}</h3>
                            <p>{{$blog->content}}</p>
                            <span class="date small">{{$blog->created_at}}</span>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>
