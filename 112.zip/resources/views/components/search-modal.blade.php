<div class="modal fade" id="searchModal" tabindex="-1" aria-labelledby="searchModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
            <button type="submit" class="close ml-auto" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
            </button>
            <div class="modal-header">
                <h4 class="modal-title" id="searchModalLabel">
                    البحث
                </h4>
            </div>
            <div class="modal-body">
                <form method="GET" action="{{route('website.search')}}" siq_id="autopick_7098">
                    <div class="form-row">
                        <div class="form-group col-lg-9">
                            <label for="searchInput" class="sr-only">البحث</label>
                            <input autofocus="" type="search" name="keyword" class="form-control" id="searchInput" value="" placeholder="هل تبحث عن طبيب أو خدمة أو أي شئ؟">
                        </div>
                        <div class="form-group col-lg-3">
                            <button type="submit" class="btn btn-brand-primary btn-block">إبحث الآن</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

