<div class="slider">
    <div class="swiper mainSlider">
        <div class="swiper-wrapper">

            <div class="swiper-slide">
                <div class="slider__slide">

                    <div class="slider__image">
                        <picture>
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-1.jpg')}}" type="image/webp">
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-1.jpg')}}" type="image/jpeg">
                            <img class="swiper-lazy lazyload" src="{{asset('assets/images/slider/slider-1.jpg')}}" draggable="false" alt="alt">
                        </picture>
                        <div class="swiper-lazy-preloader"></div>
                    </div>


                    <div class="slider__text">
                        <div class="container">
                            <div class="info wrapper960"><div class="info-wrapper" style="max-width: 500px;"><div class="layerslideshow-title-container"><h2 class="layerslideshow-title">برنامج فحص الوافدين</h2></div><div class="layerslideshow-caption">يستهدف الفحص الطبي للوافدين اتخاذ الإجراءات الصحية المناسبة للتأكد من خلو الوافدين لدول مجلس التعاون الخليجي من الأمراض التي تشكل خطراً على مخالطيهم بما يهدد أمن وسلامة مجتمع دول المجلس، والتأكد من اللياقة الصحية للوافدين لغرض العمل أو الزيارة أو الاقامة أو لأي أغراض أخرى تحددها تلك الدول.</div></div></div>
                            <div class="slider__actions" data-aos="fade-up" data-aos-delay="500">
                                <a href="{{route('website.appointment')}}" class="btn btn-brand-primary Booking_ads">
                                    إحجز الآن
                                    <svg class="btn-icon">
                                        <use href="{{asset('assets/images/icons/icons.svg?v=32#book')}}"></use>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="swiper-slide">
                <div class="slider__slide">

                    <div class="slider__image">
                        <picture>
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-2.jpg')}}" type="image/webp">
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-2.jpg')}}" type="image/jpeg">
                            <img class="swiper-lazy lazyload" src="{{asset('assets/images/slider/slider-2.jpg')}}" draggable="false" alt="alt">
                        </picture>
                        <div class="swiper-lazy-preloader"></div>
                    </div>


                    <div class="slider__text">
                        <div class="container">
                            <div class="info-wrapper" style="max-width: 500px;"><div class="layerslideshow-title-container"><h2 class="layerslideshow-title">مركز نيو الطبي</h2></div><div class="layerslideshow-caption">مركز نيو الطبي هي شبكة متكاملة من مراكز الرعاية الصحية التي تضم العيادات الطبية المتخصصة والمختبرات الطبية ومراكز الاشعة .

                                    كل ذلك تحت مظلة واحدة لتوفير رعاية صحية مهنية كاملة وشاملة تحت سقف واحد. أيضًا يوفر مركز نيو الطبي  أفضل رعاية على المستوى المحلي و الدولي . </div></div>
                            <div class="slider__actions" data-aos="fade-up" data-aos-delay="500">
                                <a href="{{route('website.appointment')}}" class="btn btn-brand-primary Booking_ads">
                                    إحجز الآن
                                    <svg class="btn-icon">
                                        <use href="{{asset('assets/images/icons/icons.svg?v=32#book')}}"></use>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <div class="swiper-slide">
                <div class="slider__slide">

                    <div class="slider__image">
                        <picture>
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-3.jpg')}}" type="image/webp">
                            <source class="swiper-lazy" srcset="{{asset('assets/images/slider/slider-3.jpg')}}" type="image/jpeg">
                            <img class="swiper-lazy lazyload" src="{{asset('assets/images/slider/slider-3.jpg')}}" draggable="false" alt="alt">
                        </picture>
                        <div class="swiper-lazy-preloader"></div>
                    </div>


                    <div class="slider__text">
                        <div class="container">
                            <div class="info wrapper960"><div class="info-wrapper" style="max-width: 500px;"><div class="layerslideshow-title-container"><h2 class="layerslideshow-title">نيو لاب</h2></div><div class="layerslideshow-caption">مختبرات نيولاب تسعى دائما الى الجودة و التطور المستمر و التقدم التكنولوجي نهدف بتزويد المرضى بخدمات صحية متميزة ذات معاير دولية بسرعة و جودة و بسعر منافس
                                        تتمثل مهمة نيولاب في توفير عمليات مخبرية عالية الجودة و فعالة والمضي قدما للارتقاء و التمتع بمكانه ريادية و مرموقة في مجال مختبرات و التحاليل الطبية من خلال تقديم افضل و أجود الخدمات المخبرية الشاملة.</div></div></div>
                            <div class="slider__actions" data-aos="fade-up" data-aos-delay="500">
                                <a href="{{route('website.appointment')}}" class="btn btn-brand-primary Booking_ads">
                                    إحجز الآن
                                    <svg class="btn-icon">
                                        <use href="{{asset('assets/images/icons/icons.svg?v=32#book')}}"></use>
                                    </svg>
                                </a>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>
