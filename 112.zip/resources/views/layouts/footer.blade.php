
<footer class="footer">
    <div class="container">
        <div class="row">

            <div class="col-xl-1">
                <div class="footer__logo" data-aos="fade-up">
                    <picture>
                        <source srcset="{{asset('assets/images/logo.png?v=32')}}" type="image/webp" />
                        <img src="{{asset('assets/images/logo.png?v=32')}}" draggable="false" loading="lazy" alt="logo" width="70" height="50" />
                    </picture>
                </div>
            </div>


            <div class="col-xl-7">
                <div class="footer__list-container">
                    <div class="footer__list" data-aos="fade-up">
                        <ul class="list-unstyled">
                            <li><a href="{{route('website.home')}}">الرئيسية</a></li>
                            <li><a href="{{route('website.page.about_us')}}">عن مركز نيو الطبي</a></li>
                            <li><a href="{{route('website.doctor')}}">الأطباء</a></li>
                            <li><a href="{{route('website.blog.index')}}">الأخبار والمقالات</a></li>
                        </ul>
                    </div>
                    <div class="footer__list" data-aos="fade-up">
                        <h6>الخدمات:</h6>
                        <ul class="list-unstyled">
                            @foreach(\App\Models\ServiceCategory::limit(6)->get() as $category)
                                <li>
                                    <a href="{{route('website.service.index')}}">
                                        {{$category->name_ar}}
                                    </a>
                                </li>
                            @endforeach
                        </ul>
                    </div>

                </div>
            </div>


            <div class="col-xl-4">
                <div class="footer__social" data-aos="fade-up">
                    <div class=" w-100">
                        <ul class="">
                            <li class="">
                                <a href="https://www.google.com/maps/place/%D9%85%D8%B1%D9%83%D8%B2+%D9%8A%D9%86%D8%A8%D8%B9+%D8%A7%D9%84%D8%B7%D8%A8%D9%8A+Yanbu+medical+Center%E2%80%AD/@31.9496887,35.9065665,15z/data=!4m5!3m4!1s0x0:0x873aecb135e74302!8m2!3d31.9496887!4d35.9065665?coh=164777&entry=tt&shorturl=1" title="address">
                                   Ibn Khaldoun St. Amman - Jordan</i>
                                </a>
                            </li>
                            <li class="">
                                <a href="" title="email">
                                    <i class="fa fa-email">info@neocenter.jo</i>
                                </a>
                            </li>
                            <li class="">
                                <a href="https://wa.me/962791915560" title="whatsapp">
                                    962791915560
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>

                <div class="top-bar__block social aos-init aos-animate" data-aos="fade-down">
                    <ul class="list-inline">
                        <li class="list-inline-item">
                            <a href="" title="Facebook">
                                <svg class="icon">
                                    <use href="{{asset('assets/images/icons/icons.svg?v=32#facebook')}}"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="" title="Instagram">
                                <svg class="icon">
                                    <use href="{{asset('assets/images/icons/icons.svg?v=32#instagram')}}"></use>
                                </svg>
                            </a>
                        </li>
                        <li class="list-inline-item">
                            <a href="" title="LinkedIn">
                                <svg class="icon">
                                    <use href="{{asset('assets/images/icons/icons.svg?v=32#linkedin')}}"></use>
                                </svg>
                            </a>
                        </li>

                    </ul>
                </div>
            </div>



        </div>
    </div>

    <div class="footer__copyrights text-center">
        <small>
            &copy; 2023. جميع الحقوق محفوظة لـ عيادات نيو.
        </small>
    </div>

</footer>
