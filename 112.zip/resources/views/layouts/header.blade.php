        <header class="header" id="header">

    <div class="header__nav container" data-aos="fade-up" data-aos-delay="200">
        <nav class="navbar navbar-expand-xl navbar-light">

            <a class="navbar-brand" href="{{url('/')}}">
                <picture>
                    <source srcset="{{asset('assets/images/logo.png?v=32')}}" type="image/webp" />
                    <img src="{{asset('assets/images/logo.png?v=32')}}" alt="ram clinics logo" width="30" height="55" />
                </picture>
            </a>


            <div class="mobile-icons">
{{--                <a href="https://ramclinics.net?lang=en" class="d-xl-none lang">English</a>--}}
                <button type="button" class="btn btn-white btn-icon d-xl-none" data-toggle="modal" data-target="#searchModal">
                    <span class="sr-only">البحث</span>
                    <svg>
                        <use href="/web/assets/images/icons/icons.svg?v=32#search"></use>
                    </svg>
                </button>
                <button class="btn navbar-toggler" type="button" data-toggle="collapse" data-target="#ramNavbar" aria-controls="ramNavbar" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
            </div>


            <div class="collapse navbar-collapse" id="ramNavbar">
                <ul class="navbar-nav ml-auto mr-auto">
                    <li class="nav-item ">
                        <a class="nav-link" href="{{route('website.home')}}">الرئيسية <span class="sr-only">(الحالي)</span></a>
                    </li>
                    <li class="nav-item ">
                        <a class="nav-link" href="{{route('website.page.about_us')}}">
                            عن مركز نيو الطبي</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="servicesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            الخدمات </a>
                        <div class="dropdown-menu" aria-labelledby="servicesDropdown">
                            @foreach(\App\Models\ServiceCategory::all() as $service)
                            <a class="dropdown-item" href="{{route('website.appointment')}}">
                                {{$service->name_ar}}
                            </a>
                            @endforeach
                        </div>
                    </li>
                   {{-- <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="offersDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            العروض </a>
                        <div class="dropdown-menu" aria-labelledby="offersDropdown">
                                <a class="dropdown-item" href="{{route('website.page.offers')}}">كل العروض</a>
                              </div>
                    </li>

                    <li class="nav-item ">
                        <a class="nav-link" href="{{route('website.discount.index')}}">خصومات الشركاء</a>
                    </li>--}}

                    <li class="nav-item ">
                        <a class="nav-link" href="{{route('website.doctor')}}">الأطباء</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" id="blogDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            الأخبار والمقالات </a>
                        <div class="dropdown-menu" aria-labelledby="blogDropdown">
                            <a class="dropdown-item" href="{{route('website.blog.index')}}">جميع المقالات</a>
                        </div>
                    </li>

                    <li class="nav-item">
                        <a class="nav-link" href="{{route('website.feedback')}}">
                            قيم زيارتك
                        </a>

                    </li>
                </ul>

                <div class="my-2 my-lg-0 d-xl-inline-block">
                    <button type="button" class="btn btn-white d-none d-xl-inline-block" data-toggle="modal" data-target="#searchModal">
                        <span class="sr-only">البحث</span>
                        <svg class="btn-icon"><use href="{{asset('assets/images/icons/icons.svg?v=32#search')}}"></use></svg>
                    </button>
                    <a href="{{route('website.appointment')}}" class="btn btn-brand-primary Booking_ads">
                        إحجز الآن <svg class="btn-icon"><use href="{{asset('assets/images/icons/icons.svg?v=32#book')}}"></use></svg>
                    </a>
                </div>

            </div>


        </nav>
    </div>

</header>
